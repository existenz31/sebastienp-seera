const { collection } = require('forest-express-sequelize');
const models = require('../models');

// This file allows you to add to your Forest UI:
// - Smart actions: https://docs.forestadmin.com/documentation/reference-guide/actions/create-and-manage-smart-actions
// - Smart fields: https://docs.forestadmin.com/documentation/reference-guide/fields/create-and-manage-smart-fields
// - Smart relationships: https://docs.forestadmin.com/documentation/reference-guide/relationships/create-a-smart-relationship
// - Smart segments: https://docs.forestadmin.com/documentation/reference-guide/segments/smart-segments
collection('property', {
  actions: [],
  fields: [
    {
      field:'locationMap',
      type: 'String',
      get: (property) => {
        return `${property.latitude}, ${property.longitude}`;
      }
    },
    // {
    //   field:'location',
    //   type: 'String',
    //   reference: 'country.id',
    //   // get: (property) => {
    //   //   return property.location;
    //   // }
    // },
    // {
    //   field:'country',
    //   type: 'String',
    //   reference: 'country.id',
    //   isFilterable: true
    // },
    // {
    //   field:'city',
    //   type: 'String',
    //   reference: 'city.id',
    //   isFilterable: true
    // },
    // {
    //   field:'region',
    //   type: 'String',
    //   reference: 'region.id',
    //   isFilterable: true
    // },
    // {
    //   field:'area',
    //   type: 'String',
    //   reference: 'area.id',
    //   isFilterable: true
    // },
    ],
  segments: [],
});
